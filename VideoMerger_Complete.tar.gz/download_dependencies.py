#!/usr/bin/env python3
"""
VideoMerger Dependency Downloader
Automatically downloads and sets up required dependencies
"""

import os
import sys
import urllib.request
import zipfile
import shutil
from pathlib import Path

def download_file(url, filename):
    """Download file with progress bar"""
    print(f"Downloading {filename}...")
    
    def progress_hook(count, block_size, total_size):
        percent = int(count * block_size * 100 / total_size)
        sys.stdout.write(f"\r{filename}: {percent}%")
        sys.stdout.flush()
    
    urllib.request.urlretrieve(url, filename, progress_hook)
    print()

def setup_imgui():
    """Download and setup Dear ImGui"""
    print("Setting up Dear ImGui...")
    
    if Path("imgui/imgui.h").exists():
        print("Dear ImGui already exists, skipping...")
        return
    
    imgui_url = "https://github.com/ocornut/imgui/archive/refs/heads/docking.zip"
    download_file(imgui_url, "imgui.zip")
    
    with zipfile.ZipFile("imgui.zip", 'r') as zip_ref:
        zip_ref.extractall("temp")
    
    # Move extracted files to imgui directory
    shutil.move("temp/imgui-docking", "imgui")
    
    # Cleanup
    os.remove("imgui.zip")
    shutil.rmtree("temp")
    
    print("Dear ImGui setup completed!")

def setup_gl3w():
    """Download and setup GL3W"""
    print("Setting up GL3W...")
    
    if Path("gl3w/include/GL/gl3w.h").exists():
        print("GL3W already exists, skipping...")
        return
    
    # Create directories
    Path("gl3w/include/GL").mkdir(parents=True, exist_ok=True)
    Path("gl3w/src").mkdir(parents=True, exist_ok=True)
    
    # Download GL3W header
    gl3w_h_url = "https://raw.githubusercontent.com/skaslev/gl3w/master/include/GL/gl3w.h"
    download_file(gl3w_h_url, "gl3w/include/GL/gl3w.h")
    
    # Download GL3W source
    gl3w_c_url = "https://raw.githubusercontent.com/skaslev/gl3w/master/src/gl3w.c"
    download_file(gl3w_c_url, "gl3w/src/gl3w.c")
    
    # Download glcorearb.h
    glcorearb_url = "https://raw.githubusercontent.com/skaslev/gl3w/master/include/GL/glcorearb.h"
    download_file(glcorearb_url, "gl3w/include/GL/glcorearb.h")
    
    print("GL3W setup completed!")

def setup_ffmpeg():
    """Instructions for FFmpeg setup"""
    print("FFmpeg Setup Instructions:")
    print("=" * 50)
    print("FFmpeg requires manual download due to licensing:")
    print()
    print("1. Visit: https://github.com/BtbN/FFmpeg-Builds/releases")
    print("2. Download: ffmpeg-master-latest-win64-gpl-shared.zip")
    print("3. Extract to: C:\\ffmpeg")
    print()
    print("Directory structure should be:")
    print("C:\\ffmpeg\\")
    print("  ├── bin\\       (ffmpeg.exe, etc)")
    print("  ├── include\\   (header files)")
    print("  └── lib\\       (library files)")
    print()
    print("Alternative: Use vcpkg to install FFmpeg")
    print("vcpkg install ffmpeg[core]:x64-windows-static")

def create_placeholder_icon():
    """Create placeholder icon file"""
    Path("resources").mkdir(exist_ok=True)
    
    if not Path("resources/icon.ico").exists():
        # Create minimal ICO file (placeholder)
        ico_data = b'\x00\x00\x01\x00\x01\x00\x10\x10\x00\x00\x01\x00\x20\x00\x68\x04\x00\x00\x16\x00\x00\x00'
        with open("resources/icon.ico", "wb") as f:
            f.write(ico_data)
        print("Created placeholder icon.ico")

def main():
    """Main setup function"""
    print("VideoMerger Dependency Setup")
    print("=" * 40)
    
    try:
        setup_imgui()
        setup_gl3w()
        setup_ffmpeg()
        create_placeholder_icon()
        
        print()
        print("Setup completed!")
        print("=" * 40)
        print("Next steps:")
        print("1. Install Visual Studio 2019/2022 with C++ tools")
        print("2. Install CMake 3.16+")
        print("3. Setup FFmpeg as described above")
        print("4. Run: build.bat")
        print()
        print("For detailed instructions, see BUILD_INSTRUCTIONS.md")
        
    except Exception as e:
        print(f"Error during setup: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()