#include "VideoProcessor.h"
#include <algorithm>
#include <regex>
#include <filesystem>
#include <iostream>

VideoProcessor::VideoProcessor()
    : m_videoCRF(23)
    , m_audioBitrate(128)
    , m_outputFormat("mp4")
    , m_isInitialized(false)
    , m_totalFiles(0)
    , m_currentFileIndex(0)
{
    Initialize();
}

VideoProcessor::~VideoProcessor()
{
    Cleanup();
}

bool VideoProcessor::Initialize()
{
    if (m_isInitialized)
        return true;

    return InitializeFFmpeg();
}

void VideoProcessor::Cleanup()
{
    if (m_isInitialized)
    {
        CleanupFFmpeg();
        m_isInitialized = false;
    }
}

bool VideoProcessor::InitializeFFmpeg()
{
    // Initialize FFmpeg (for older versions, newer versions don't need this)
    #if LIBAVFORMAT_VERSION_INT < AV_VERSION_INT(58, 9, 100)
    av_register_all();
    #endif

    // Initialize network if needed
    avformat_network_init();

    m_isInitialized = true;
    return true;
}

void VideoProcessor::CleanupFFmpeg()
{
    avformat_network_deinit();
}

bool VideoProcessor::MergeVideos(const std::vector<std::string>& inputFiles, 
                                 const std::string& outputFile, 
                                 ProgressCallback progressCallback)
{
    if (inputFiles.empty())
        return false;

    m_currentProgressCallback = progressCallback;
    m_totalFiles = inputFiles.size();
    m_currentFileIndex = 0;

    if (progressCallback)
        progressCallback(0.0f, "Initializing merge process...");

    try
    {
        // Create output format context
        AVFormatContext* outputCtx = nullptr;
        int ret = avformat_alloc_output_context2(&outputCtx, nullptr, nullptr, outputFile.c_str());
        if (ret < 0)
        {
            if (progressCallback)
                progressCallback(0.0f, "Failed to create output context");
            return false;
        }

        // Open first input file to get stream information
        AVFormatContext* firstInputCtx = OpenInputFile(inputFiles[0]);
        if (!firstInputCtx)
        {
            avformat_free_context(outputCtx);
            return false;
        }

        // Create output streams based on first input
        std::vector<int> streamMap;
        for (unsigned int i = 0; i < firstInputCtx->nb_streams; i++)
        {
            AVStream* inputStream = firstInputCtx->streams[i];
            AVStream* outputStream = avformat_new_stream(outputCtx, nullptr);
            
            if (!outputStream)
            {
                CloseContext(firstInputCtx);
                avformat_free_context(outputCtx);
                return false;
            }

            // Copy codec parameters
            ret = avcodec_parameters_copy(outputStream->codecpar, inputStream->codecpar);
            if (ret < 0)
            {
                CloseContext(firstInputCtx);
                avformat_free_context(outputCtx);
                return false;
            }

            streamMap.push_back(i);
        }

        // Open output file
        if (!(outputCtx->oformat->flags & AVFMT_NOFILE))
        {
            ret = avio_open(&outputCtx->pb, outputFile.c_str(), AVIO_FLAG_WRITE);
            if (ret < 0)
            {
                CloseContext(firstInputCtx);
                avformat_free_context(outputCtx);
                return false;
            }
        }

        // Write header
        ret = avformat_write_header(outputCtx, nullptr);
        if (ret < 0)
        {
            CloseContext(firstInputCtx);
            if (!(outputCtx->oformat->flags & AVFMT_NOFILE))
                avio_closep(&outputCtx->pb);
            avformat_free_context(outputCtx);
            return false;
        }

        CloseContext(firstInputCtx);

        // Process each input file
        for (size_t fileIndex = 0; fileIndex < inputFiles.size(); fileIndex++)
        {
            m_currentFileIndex = fileIndex;
            
            if (progressCallback)
            {
                float progress = static_cast<float>(fileIndex) / static_cast<float>(inputFiles.size());
                std::string task = "Processing file " + std::to_string(fileIndex + 1) + 
                                 " of " + std::to_string(inputFiles.size());
                progressCallback(progress, task);
            }

            AVFormatContext* inputCtx = OpenInputFile(inputFiles[fileIndex]);
            if (!inputCtx)
                continue;

            // Read and write packets
            AVPacket* packet = av_packet_alloc();
            while (av_read_frame(inputCtx, packet) >= 0)
            {
                // Rescale packet timestamps
                if (packet->stream_index < streamMap.size())
                {
                    AVStream* inputStream = inputCtx->streams[packet->stream_index];
                    AVStream* outputStream = outputCtx->streams[streamMap[packet->stream_index]];

                    // Rescale timestamps
                    packet->pts = av_rescale_q_rnd(packet->pts, inputStream->time_base, 
                                                   outputStream->time_base, 
                                                   static_cast<AVRounding>(AV_ROUND_NEAR_INF | AV_ROUND_PASS_MINMAX));
                    packet->dts = av_rescale_q_rnd(packet->dts, inputStream->time_base, 
                                                   outputStream->time_base, 
                                                   static_cast<AVRounding>(AV_ROUND_NEAR_INF | AV_ROUND_PASS_MINMAX));
                    packet->duration = av_rescale_q(packet->duration, inputStream->time_base, 
                                                     outputStream->time_base);
                    packet->pos = -1;
                    packet->stream_index = streamMap[packet->stream_index];

                    // Write packet
                    ret = av_interleaved_write_frame(outputCtx, packet);
                    if (ret < 0)
                        break;
                }

                av_packet_unref(packet);
            }

            av_packet_free(&packet);
            CloseContext(inputCtx);
        }

        // Write trailer
        av_write_trailer(outputCtx);

        // Cleanup
        if (!(outputCtx->oformat->flags & AVFMT_NOFILE))
            avio_closep(&outputCtx->pb);
        avformat_free_context(outputCtx);

        if (progressCallback)
            progressCallback(1.0f, "Merge completed successfully");

        return true;
    }
    catch (const std::exception& e)
    {
        if (progressCallback)
            progressCallback(0.0f, "Error: " + std::string(e.what()));
        return false;
    }
}

bool VideoProcessor::GetVideoInfo(const std::string& inputFile, 
                                  int& width, int& height, 
                                  double& duration, double& fps)
{
    AVFormatContext* ctx = OpenInputFile(inputFile);
    if (!ctx)
        return false;

    // Find video stream
    int videoStreamIndex = -1;
    for (unsigned int i = 0; i < ctx->nb_streams; i++)
    {
        if (ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            videoStreamIndex = i;
            break;
        }
    }

    if (videoStreamIndex == -1)
    {
        CloseContext(ctx);
        return false;
    }

    AVStream* videoStream = ctx->streams[videoStreamIndex];
    
    width = videoStream->codecpar->width;
    height = videoStream->codecpar->height;
    duration = static_cast<double>(ctx->duration) / AV_TIME_BASE;
    
    if (videoStream->r_frame_rate.den > 0)
        fps = static_cast<double>(videoStream->r_frame_rate.num) / videoStream->r_frame_rate.den;
    else
        fps = 0.0;

    CloseContext(ctx);
    return true;
}

bool VideoProcessor::ApplyAntiCopyrightFilter(const std::string& inputFile, 
                                              const std::string& outputFile)
{
    // Simple anti-copyright implementation: slightly adjust video speed and add subtle noise
    // This is a basic implementation - more sophisticated methods would be needed for real use
    
    // For now, return true as placeholder
    // Real implementation would use FFmpeg filters to:
    // 1. Slightly change playback speed (0.98x - 1.02x)
    // 2. Add subtle noise or grain
    // 3. Adjust color saturation slightly
    // 4. Crop and resize by small amounts
    
    return true;
}

std::vector<std::string> VideoProcessor::SortVideosByEpisode(const std::vector<std::string>& files)
{
    std::vector<std::pair<int, std::string>> episodeFiles;
    
    for (const auto& file : files)
    {
        int episodeNumber = ExtractEpisodeNumber(file);
        episodeFiles.push_back({episodeNumber, file});
    }
    
    // Sort by episode number
    std::sort(episodeFiles.begin(), episodeFiles.end());
    
    std::vector<std::string> sortedFiles;
    for (const auto& pair : episodeFiles)
    {
        sortedFiles.push_back(pair.second);
    }
    
    return sortedFiles;
}

AVFormatContext* VideoProcessor::OpenInputFile(const std::string& filename)
{
    AVFormatContext* ctx = nullptr;
    int ret = avformat_open_input(&ctx, filename.c_str(), nullptr, nullptr);
    if (ret < 0)
        return nullptr;

    ret = avformat_find_stream_info(ctx, nullptr);
    if (ret < 0)
    {
        avformat_close_input(&ctx);
        return nullptr;
    }

    return ctx;
}

AVFormatContext* VideoProcessor::CreateOutputContext(const std::string& filename)
{
    AVFormatContext* ctx = nullptr;
    int ret = avformat_alloc_output_context2(&ctx, nullptr, nullptr, filename.c_str());
    if (ret < 0)
        return nullptr;

    return ctx;
}

void VideoProcessor::CloseContext(AVFormatContext* context)
{
    if (context)
    {
        avformat_close_input(&context);
    }
}

int VideoProcessor::ExtractEpisodeNumber(const std::string& filename)
{
    // Extract episode number from filename using regex
    std::filesystem::path path(filename);
    std::string basename = path.stem().string();
    
    // Common patterns for episode numbers
    std::vector<std::regex> patterns = {
        std::regex(R"([Ee]p?\.?\s*(\d+))", std::regex_constants::icase),
        std::regex(R"([Ee]pisode\s*(\d+))", std::regex_constants::icase),
        std::regex(R"(\b(\d+)\b)"), // Any number
        std::regex(R"([Ss]\d+[Ee](\d+))", std::regex_constants::icase), // S01E01 format
    };
    
    for (const auto& pattern : patterns)
    {
        std::smatch match;
        if (std::regex_search(basename, match, pattern))
        {
            try
            {
                return std::stoi(match[1].str());
            }
            catch (...)
            {
                continue;
            }
        }
    }
    
    // If no episode number found, return 0
    return 0;
}

double VideoProcessor::CalculateVideoSimilarity(const std::string& file1, const std::string& file2)
{
    // Placeholder for video similarity calculation
    // Real implementation would compare:
    // - Video resolution
    // - Frame rate
    // - Codec
    // - Duration patterns
    // - File naming patterns
    
    return 0.5; // Placeholder value
}