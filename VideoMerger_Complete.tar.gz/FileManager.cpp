#include "FileManager.h"
#include <filesystem>
#include <algorithm>
#include <locale>
#include <codecvt>

FileManager::FileManager()
    : m_comInitialized(false)
{
    // Initialize video file extensions
    m_videoExtensions = {
        ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", 
        ".m4v", ".3gp", ".ogv", ".ts", ".mts", ".vob", ".rm", 
        ".rmvb", ".asf", ".divx", ".xvid"
    };

    InitializeCommonDialog();
}

FileManager::~FileManager()
{
    if (m_comInitialized)
    {
        CoUninitialize();
    }
}

void FileManager::InitializeCommonDialog()
{
    HRESULT hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (SUCCEEDED(hr))
    {
        m_comInitialized = true;
    }
}

std::vector<std::string> FileManager::OpenFileDialog(bool multiSelect)
{
    std::vector<std::string> selectedFiles;

    OPENFILENAMEA ofn;
    char szFile[32768] = {0}; // Large buffer for multiple files
    
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = "Video Files\0*.mp4;*.avi;*.mkv;*.mov;*.wmv;*.flv;*.webm;*.m4v;*.3gp\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
    
    if (multiSelect)
    {
        ofn.Flags |= OFN_ALLOWMULTISELECT | OFN_EXPLORER;
    }

    if (GetOpenFileNameA(&ofn))
    {
        if (multiSelect)
        {
            // Parse multiple file selection
            std::string directory = szFile;
            char* fileName = szFile + directory.length() + 1;
            
            if (*fileName == '\0')
            {
                // Only one file selected
                selectedFiles.push_back(directory);
            }
            else
            {
                // Multiple files selected
                while (*fileName)
                {
                    std::string fullPath = directory + "\\" + fileName;
                    selectedFiles.push_back(fullPath);
                    fileName += strlen(fileName) + 1;
                }
            }
        }
        else
        {
            selectedFiles.push_back(szFile);
        }
    }

    return selectedFiles;
}

std::string FileManager::SaveFileDialog(const std::string& defaultName)
{
    OPENFILENAMEA ofn;
    char szFile[260] = {0};
    
    if (!defaultName.empty())
    {
        strcpy_s(szFile, defaultName.c_str());
    }

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = "MP4 Video\0*.mp4\0AVI Video\0*.avi\0MKV Video\0*.mkv\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
    ofn.lpstrDefExt = "mp4";

    if (GetSaveFileNameA(&ofn))
    {
        return szFile;
    }

    return "";
}

std::string FileManager::SelectFolderDialog()
{
    std::string selectedFolder;

    if (m_comInitialized)
    {
        IFileDialog* pfd = nullptr;
        HRESULT hr = CoCreateInstance(CLSID_FileOpenDialog, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pfd));
        
        if (SUCCEEDED(hr))
        {
            DWORD dwOptions;
            hr = pfd->GetOptions(&dwOptions);
            if (SUCCEEDED(hr))
            {
                hr = pfd->SetOptions(dwOptions | FOS_PICKFOLDERS);
                if (SUCCEEDED(hr))
                {
                    hr = pfd->Show(NULL);
                    if (SUCCEEDED(hr))
                    {
                        IShellItem* psi = nullptr;
                        hr = pfd->GetResult(&psi);
                        if (SUCCEEDED(hr))
                        {
                            PWSTR pszPath = nullptr;
                            hr = psi->GetDisplayName(SIGDN_FILESYSPATH, &pszPath);
                            if (SUCCEEDED(hr))
                            {
                                selectedFolder = WideStringToString(pszPath);
                                CoTaskMemFree(pszPath);
                            }
                            psi->Release();
                        }
                    }
                }
            }
            pfd->Release();
        }
    }

    return selectedFolder;
}

bool FileManager::FileExists(const std::string& filepath)
{
    return std::filesystem::exists(filepath);
}

bool FileManager::CreateDirectory(const std::string& path)
{
    try
    {
        return std::filesystem::create_directories(path);
    }
    catch (...)
    {
        return false;
    }
}

bool FileManager::DeleteFile(const std::string& filepath)
{
    try
    {
        return std::filesystem::remove(filepath);
    }
    catch (...)
    {
        return false;
    }
}

bool FileManager::IsVideoFile(const std::string& filepath)
{
    std::string extension = GetFileExtension(filepath);
    std::transform(extension.begin(), extension.end(), extension.begin(), ::tolower);
    
    return std::find(m_videoExtensions.begin(), m_videoExtensions.end(), extension) != m_videoExtensions.end();
}

std::string FileManager::GetFileExtension(const std::string& filepath)
{
    std::filesystem::path path(filepath);
    return path.extension().string();
}

long long FileManager::GetFileSize(const std::string& filepath)
{
    try
    {
        return std::filesystem::file_size(filepath);
    }
    catch (...)
    {
        return -1;
    }
}

std::string FileManager::GetFileName(const std::string& filepath)
{
    std::filesystem::path path(filepath);
    return path.filename().string();
}

std::string FileManager::GetFileDirectory(const std::string& filepath)
{
    std::filesystem::path path(filepath);
    return path.parent_path().string();
}

std::string FileManager::CombinePath(const std::string& dir, const std::string& filename)
{
    std::filesystem::path path = std::filesystem::path(dir) / filename;
    return path.string();
}

std::string FileManager::WideStringToString(const std::wstring& wstr)
{
    if (wstr.empty()) return std::string();
    
    int size_needed = WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), NULL, 0, NULL, NULL);
    std::string strTo(size_needed, 0);
    WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), &strTo[0], size_needed, NULL, NULL);
    return strTo;
}

std::wstring FileManager::StringToWideString(const std::string& str)
{
    if (str.empty()) return std::wstring();
    
    int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
    std::wstring wstrTo(size_needed, 0);
    MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
    return wstrTo;
}