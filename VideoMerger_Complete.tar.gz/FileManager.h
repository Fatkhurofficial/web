#pragma once

#include <string>
#include <vector>
#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>

class FileManager
{
public:
    FileManager();
    ~FileManager();

    // File dialog operations
    std::vector<std::string> OpenFileDialog(bool multiSelect = false);
    std::string SaveFileDialog(const std::string& defaultName = "");
    std::string SelectFolderDialog();

    // File operations
    bool FileExists(const std::string& filepath);
    bool CreateDirectory(const std::string& path);
    bool DeleteFile(const std::string& filepath);
    
    // Video file validation
    bool IsVideoFile(const std::string& filepath);
    std::string GetFileExtension(const std::string& filepath);
    long long GetFileSize(const std::string& filepath);

    // Path utilities
    std::string GetFileName(const std::string& filepath);
    std::string GetFileDirectory(const std::string& filepath);
    std::string CombinePath(const std::string& dir, const std::string& filename);

private:
    void InitializeCommonDialog();
    std::string WideStringToString(const std::wstring& wstr);
    std::wstring StringToWideString(const std::string& str);

    // Video file extensions
    std::vector<std::string> m_videoExtensions;
    
    // COM initialization
    bool m_comInitialized;
};