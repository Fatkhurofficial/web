#include "ProgressTracker.h"
#include <shellapi.h>
#include <iostream>

ProgressTracker::ProgressTracker()
    : m_progress(0.0f)
    , m_currentTask("Ready")
    , m_isProcessing(false)
    , m_trayWindow(nullptr)
    , m_trayInitialized(false)
    , m_timerStarted(false)
{
    ZeroMemory(&m_trayIconData, sizeof(m_trayIconData));
    QueryPerformanceFrequency(&m_frequency);
    InitializeSystemTray();
}

ProgressTracker::~ProgressTracker()
{
    CleanupSystemTray();
}

void ProgressTracker::SetProgress(float progress, const std::string& task)
{
    m_progress = std::clamp(progress, 0.0f, 1.0f);
    
    if (!task.empty())
    {
        m_currentTask = task;
    }

    UpdateTrayIcon();

    // Show notification for major milestones
    if (progress >= 1.0f && m_isProcessing)
    {
        ShowNotification("VideoMerger", "Video merge completed successfully!");
    }
    else if (progress >= 0.5f && progress < 0.51f && m_isProcessing)
    {
        ShowNotification("VideoMerger", "Video merge is 50% complete");
    }
}

void ProgressTracker::ShowNotification(const std::string& title, const std::string& message)
{
    if (!m_trayInitialized)
        return;

    // Update notification data
    m_trayIconData.uFlags = NIF_INFO;
    strcpy_s(m_trayIconData.szInfoTitle, title.c_str());
    strcpy_s(m_trayIconData.szInfo, message.c_str());
    m_trayIconData.dwInfoFlags = NIIF_INFO;
    m_trayIconData.uTimeout = 5000; // 5 seconds

    Shell_NotifyIcon(NIM_MODIFY, &m_trayIconData);

    // Call custom notification callback if set
    if (m_notificationCallback)
    {
        m_notificationCallback(title, message);
    }
}

void ProgressTracker::SetNotificationCallback(NotificationCallback callback)
{
    m_notificationCallback = callback;
}

void ProgressTracker::SetProcessingState(bool isProcessing)
{
    m_isProcessing = isProcessing;
    
    if (isProcessing)
    {
        StartTimer();
        m_currentTask = "Processing...";
        ShowNotification("VideoMerger", "Video merge started");
    }
    else
    {
        StopTimer();
        if (m_progress >= 1.0f)
        {
            m_currentTask = "Completed";
        }
        else
        {
            m_currentTask = "Stopped";
        }
    }
    
    UpdateTrayIcon();
}

void ProgressTracker::StartTimer()
{
    QueryPerformanceCounter(&m_startTime);
    m_timerStarted = true;
}

void ProgressTracker::StopTimer()
{
    m_timerStarted = false;
}

double ProgressTracker::GetElapsedTime() const
{
    if (!m_timerStarted)
        return 0.0;

    LARGE_INTEGER currentTime;
    QueryPerformanceCounter(&currentTime);
    
    return static_cast<double>(currentTime.QuadPart - m_startTime.QuadPart) / m_frequency.QuadPart;
}

double ProgressTracker::EstimateRemainingTime() const
{
    if (!m_timerStarted || m_progress <= 0.0f)
        return 0.0;

    double elapsedTime = GetElapsedTime();
    double progressRatio = m_progress;
    
    if (progressRatio >= 1.0f)
        return 0.0;

    return (elapsedTime / progressRatio) * (1.0 - progressRatio);
}

void ProgressTracker::InitializeSystemTray()
{
    // Create a hidden window for tray messages
    WNDCLASS wc = {};
    wc.lpfnWndProc = TrayWndProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.lpszClassName = L"VideoMergerTrayClass";
    
    RegisterClass(&wc);
    
    m_trayWindow = CreateWindow(L"VideoMergerTrayClass", L"VideoMerger Tray", 
                                0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, 
                                GetModuleHandle(nullptr), this);

    if (m_trayWindow)
    {
        // Initialize tray icon data
        m_trayIconData.cbSize = sizeof(NOTIFYICONDATA);
        m_trayIconData.hWnd = m_trayWindow;
        m_trayIconData.uID = TRAY_ID;
        m_trayIconData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
        m_trayIconData.uCallbackMessage = WM_TRAYICON;
        m_trayIconData.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
        strcpy_s(m_trayIconData.szTip, "VideoMerger - Ready");

        // Add icon to system tray
        if (Shell_NotifyIcon(NIM_ADD, &m_trayIconData))
        {
            m_trayInitialized = true;
        }
    }
}

void ProgressTracker::CleanupSystemTray()
{
    if (m_trayInitialized)
    {
        Shell_NotifyIcon(NIM_DELETE, &m_trayIconData);
        m_trayInitialized = false;
    }

    if (m_trayWindow)
    {
        DestroyWindow(m_trayWindow);
        m_trayWindow = nullptr;
    }
}

void ProgressTracker::UpdateTrayIcon()
{
    if (!m_trayInitialized)
        return;

    // Update tooltip text
    std::string tooltipText = "VideoMerger - " + m_currentTask;
    if (m_isProcessing)
    {
        int progressPercent = static_cast<int>(m_progress * 100);
        tooltipText += " (" + std::to_string(progressPercent) + "%)";
    }

    strcpy_s(m_trayIconData.szTip, tooltipText.c_str());
    m_trayIconData.uFlags = NIF_TIP;
    
    Shell_NotifyIcon(NIM_MODIFY, &m_trayIconData);
}

LRESULT CALLBACK ProgressTracker::TrayWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    ProgressTracker* tracker = reinterpret_cast<ProgressTracker*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));

    switch (msg)
    {
    case WM_CREATE:
        {
            CREATESTRUCT* cs = reinterpret_cast<CREATESTRUCT*>(lParam);
            SetWindowLongPtr(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(cs->lpCreateParams));
        }
        break;

    case WM_TRAYICON:
        if (lParam == WM_LBUTTONDBLCLK)
        {
            // Double-click on tray icon - could restore main window
            // For now, just show a message
            if (tracker)
            {
                std::string message = tracker->GetCurrentTask();
                if (tracker->IsProcessing())
                {
                    int progress = static_cast<int>(tracker->GetProgress() * 100);
                    message += " (" + std::to_string(progress) + "%)";
                }
                MessageBoxA(nullptr, message.c_str(), "VideoMerger Status", MB_OK | MB_ICONINFORMATION);
            }
        }
        break;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return 0;
}