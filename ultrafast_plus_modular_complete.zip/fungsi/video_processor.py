"""
Video Processor Module - Core video processing functions
Optimized untuk ULTRAFAST PLUS dengan enhanced copyright protection
"""

import os
import random
import time
from moviepy import VideoFileClip, vfx, afx, ColorClip, CompositeVideoClip

class VideoProcessor:
    """Core video processing dengan enhanced effects untuk copyright protection"""
    
    def __init__(self, config, logger=None):
        self.config = config
        self.logger = logger
        self.processed_count = 0
        self.error_count = 0
        
    def log(self, message):
        """Helper logging function"""
        if self.logger:
            self.logger.log(message)
        else:
            print(message)
    
    def generate_ultrafast_plus_params(self, episode_num, total_episodes, video_duration=0):
        """Generate enhanced parameters untuk ULTRAFAST PLUS dengan copyright protection kuat"""
        random.seed(int(time.time()) + episode_num)

        base_variation = (episode_num % 15) / 100  # Increased variation range
        time_variation = (int(time.time()) % 1000) / 10000
        duration_factor = min(1.2, video_duration / 600)  # Factor berdasarkan durasi

        mode = self.config.get('mode', 'ultrafast_plus')

        if mode == "ultrafast_plus":
            return {
                # Speed - Enhanced variation untuk strong copyright protection
                'speed': random.uniform(1.003 + base_variation, 1.020 + time_variation),  # 0.3-2.0%
                
                # Brightness - Significant variation
                'brightness': random.uniform(1.025 + base_variation, 1.100 + time_variation),  # 2.5-10%
                
                # Margin - Noticeable variation
                'margin': random.randint(4 + (episode_num % 3), 15 + (episode_num % 5)),  # 4-20 pixels
                
                # Audio - Enhanced variation
                'audio_volume': random.uniform(0.93 + base_variation, 1.08 + time_variation),  # 7% total variation
                
                # Fade - More noticeable
                'fade_duration': random.uniform(0.018, 0.055),  # 18-55ms fade
                
                # Cropping - Lightweight tapi effective
                'crop_percent': random.uniform(0.4 + base_variation, 2.2 + time_variation),  # 0.4-2.2%
                
                # Gamma - Enhanced lightweight effect
                'gamma': random.uniform(0.93 + base_variation, 1.09 + time_variation) if random.random() < 0.85 else None,
                
                # Contrast - Subtle tapi effective
                'contrast': random.uniform(0.95 - base_variation, 1.08 + time_variation) if random.random() < 0.65 else None,
                
                # Saturation - Untuk enhanced protection
                'saturation': random.uniform(0.96 - base_variation, 1.07 + time_variation) if random.random() < 0.45 else None,
                
                # Duration-based adjustments
                'duration_factor': duration_factor
            }
        elif mode == "ultrafast":
            return {
                'speed': random.uniform(1.002, 1.010),
                'brightness': random.uniform(1.015, 1.050),
                'margin': random.randint(2, 8),
                'audio_volume': random.uniform(0.98, 1.02),
                'fade_duration': 0.010,
                'crop_percent': 0,
            }
        else:  # fast or balanced
            return {
                'speed': random.uniform(1.002, 1.015),
                'brightness': random.uniform(1.02, 1.08),
                'margin': random.randint(3, 10),
                'audio_volume': random.uniform(0.95, 1.05),
                'fade_duration': random.uniform(0.012, 0.030),
                'crop_percent': random.uniform(0.3, 1.5),
                'gamma': random.uniform(0.95, 1.07) if random.random() < 0.75 else None,
            }

    def apply_speed_modification(self, clip, speed_factor):
        """Apply speed modification dengan error handling"""
        try:
            if abs(speed_factor - 1.0) > 0.001:  # Only apply if significant change
                return vfx.MultiplySpeed(speed_factor).apply(clip)
        except Exception as e:
            self.log(f"⚠️ Speed modification failed: {e}")
        return clip

    def apply_brightness_modification(self, clip, brightness_factor):
        """Apply brightness modification dengan error handling"""
        try:
            if abs(brightness_factor - 1.0) > 0.01:  # Only apply if significant change
                return vfx.MultiplyColor(brightness_factor).apply(clip)
        except Exception as e:
            self.log(f"⚠️ Brightness modification failed: {e}")
        return clip

    def apply_margin_modification(self, clip, margin_pixels):
        """Apply margin dengan optimization"""
        try:
            if margin_pixels > 3:  # Only apply if significant margin
                return vfx.Margin(margin_pixels).apply(clip)
        except Exception as e:
            self.log(f"⚠️ Margin modification failed: {e}")
        return clip

    def apply_gamma_modification(self, clip, gamma_value):
        """Apply gamma correction dengan error handling"""
        try:
            if gamma_value and abs(gamma_value - 1.0) > 0.03:
                return vfx.GammaCorrection(gamma_value).apply(clip)
        except Exception as e:
            self.log(f"⚠️ Gamma modification failed: {e}")
        return clip

    def apply_cropping_modification(self, clip, crop_percent):
        """Apply minimal cropping untuk copyright protection dengan memory efficiency"""
        try:
            if crop_percent and crop_percent > 0.3:
                w, h = clip.size
                
                # Reduce crop impact untuk memory efficiency
                crop_factor = 1 - (crop_percent / 200)  # Halved impact
                crop_w = int(w * crop_factor)
                crop_h = int(h * crop_factor)

                # Safety checks
                if crop_w > 100 and crop_h > 100 and crop_w < w and crop_h < h:
                    x1 = (w - crop_w) // 2
                    y1 = (h - crop_h) // 2
                    
                    clipped = vfx.Crop(x1=x1, y1=y1, x2=x1+crop_w, y2=y1+crop_h).apply(clip)
                    return vfx.Resize((w, h)).apply(clipped)
        except Exception as e:
            self.log(f"⚠️ Cropping modification failed: {e}")
        return clip

    def apply_contrast_modification(self, clip, contrast_value):
        """Apply contrast using MultiplyColor untuk efficiency"""
        try:
            if contrast_value and abs(contrast_value - 1.0) > 0.02:
                # Use MultiplyColor as a proxy for contrast adjustment
                return vfx.MultiplyColor(contrast_value).apply(clip)
        except Exception as e:
            self.log(f"⚠️ Contrast modification failed: {e}")
        return clip

    def apply_audio_modifications(self, clip, params):
        """Apply comprehensive audio modifications"""
        try:
            if clip.audio is None:
                return clip

            # Volume modification
            if abs(params['audio_volume'] - 1.0) > 0.015:
                clip = afx.MultiplyVolume(params['audio_volume']).apply(clip)

            # Enhanced fade effects
            if params.get('fade_duration', 0) > 0.01:
                fade_dur = params['fade_duration']
                clip = afx.AudioFadeIn(fade_dur).apply(clip)
                clip = afx.AudioFadeOut(fade_dur).apply(clip)

        except Exception as e:
            self.log(f"⚠️ Audio modification failed: {e}")

        return clip

    def add_lightweight_overlay(self, clip, episode_num):
        """Add lightweight overlay untuk copyright protection"""
        if not self.config.get('enable_overlay', False):
            return clip

        try:
            # Reduced probability untuk memory efficiency
            if random.random() < 0.12:  # 12% chance
                w, h = clip.size
                
                # Very subtle overlay
                overlay_color = (
                    random.randint(0, 25), 
                    random.randint(0, 25), 
                    random.randint(0, 25), 
                    1
                )
                
                overlay = ColorClip(
                    size=(w, h), 
                    color=overlay_color[:3], 
                    duration=clip.duration
                )
                overlay = overlay.with_opacity(overlay_color[3] / 255.0)
                clip = CompositeVideoClip([clip, overlay])

        except Exception as e:
            self.log(f"⚠️ Overlay creation failed: {e}")

        return clip

    def apply_all_modifications(self, clip, params, episode_num):
        """Apply all modifications dalam sequence yang optimal"""
        try:
            original_duration = clip.duration if hasattr(clip, 'duration') else 0
            
            # 1. Speed modification (affects timing)
            clip = self.apply_speed_modification(clip, params['speed'])

            # 2. Visual modifications
            clip = self.apply_brightness_modification(clip, params['brightness'])
            
            # 3. Margin (affects size)
            clip = self.apply_margin_modification(clip, params.get('margin', 0))

            # 4. Advanced effects (only if enabled)
            if self.config.get('enable_complex_effects', False):
                clip = self.apply_gamma_modification(clip, params.get('gamma'))
                clip = self.apply_contrast_modification(clip, params.get('contrast'))
                clip = self.apply_cropping_modification(clip, params.get('crop_percent'))

            # 5. Audio modifications
            clip = self.apply_audio_modifications(clip, params)

            # 6. Overlay (if enabled)
            if self.config.get('enable_overlay', False):
                clip = self.add_lightweight_overlay(clip, episode_num)

            return clip

        except Exception as e:
            self.log(f"❌ Failed to apply modifications to episode {episode_num}: {e}")
            self.error_count += 1
            return clip  # Return original clip if modifications fail

    def process_single_video(self, args):
        """Process single video dengan comprehensive error handling"""
        filepath, episode_num, total_episodes = args

        try:
            # Load video dengan timeout protection
            clip = VideoFileClip(filepath)
            
            if not hasattr(clip, 'duration') or clip.duration <= 0:
                self.log(f"⚠️ Invalid video duration for {filepath}")
                clip.close()
                return None, None
            
            video_duration = clip.duration

            # Generate parameters
            params = self.generate_ultrafast_plus_params(episode_num, total_episodes, video_duration)

            # Apply all modifications
            processed_clip = self.apply_all_modifications(clip, params, episode_num)

            # Create video info
            video_info = {
                'episode': episode_num,
                'filename': os.path.basename(filepath),
                'original_duration': video_duration,
                'processed_duration': processed_clip.duration,
                'params': params,
                'copyright_protection': self.config.get('copyright_protection_level', 'standard'),
                'file_size_mb': self._get_file_size_mb(filepath),
                'processing_success': True
            }

            self.processed_count += 1
            return processed_clip, video_info

        except Exception as e:
            self.log(f"❌ Error processing {filepath}: {e}")
            self.error_count += 1
            
            # Try to close clip if it was opened
            try:
                if 'clip' in locals():
                    clip.close()
            except:
                pass
                
            return None, None

    def _get_file_size_mb(self, filepath):
        """Get file size dengan error handling"""
        try:
            import os
            return os.path.getsize(filepath) / (1024 * 1024)
        except:
            return 0

    def get_processing_stats(self):
        """Get processing statistics"""
        return {
            'processed_count': self.processed_count,
            'error_count': self.error_count,
            'success_rate': (self.processed_count / (self.processed_count + self.error_count)) * 100 if (self.processed_count + self.error_count) > 0 else 0
        }

    def estimate_video_duration(self, file_paths_sample):
        """Estimate average video duration dari sample files"""
        total_duration = 0
        sample_count = min(3, len(file_paths_sample))
        successful_samples = 0
        
        for i, (filepath, _, _) in enumerate(file_paths_sample[:sample_count]):
            try:
                with VideoFileClip(filepath) as clip:
                    if hasattr(clip, 'duration') and clip.duration > 0:
                        total_duration += clip.duration
                        successful_samples += 1
            except Exception as e:
                self.log(f"⚠️ Could not read duration from {filepath}: {e}")
                # Use default estimate
                total_duration += 900  # 15 minutes default
                successful_samples += 1
        
        if successful_samples == 0:
            return 15.0  # Default 15 minutes
            
        avg_duration_seconds = total_duration / successful_samples
        return avg_duration_seconds / 60  # Return in minutes

    def validate_video_file(self, filepath):
        """Validate video file sebelum processing"""
        try:
            import os
            
            # Check file exists and not empty
            if not os.path.exists(filepath):
                return False, "File does not exist"
            
            if os.path.getsize(filepath) < 1000:  # Less than 1KB
                return False, "File too small"
            
            # Try to open with MoviePy
            try:
                with VideoFileClip(filepath) as clip:
                    if not hasattr(clip, 'duration') or clip.duration <= 0:
                        return False, "Invalid duration"
                    if not hasattr(clip, 'size') or clip.size[0] <= 0 or clip.size[1] <= 0:
                        return False, "Invalid dimensions"
            except Exception as e:
                return False, f"Cannot open video: {e}"
                
            return True, "Valid"
            
        except Exception as e:
            return False, f"Validation error: {e}"

    def batch_validate_files(self, file_paths_with_info):
        """Validate multiple files dan return only valid ones"""
        valid_files = []
        invalid_files = []
        
        self.log(f"🔍 Validating {len(file_paths_with_info)} video files...")
        
        for filepath, episode_num, total_episodes in file_paths_with_info:
            is_valid, reason = self.validate_video_file(filepath)
            
            if is_valid:
                valid_files.append((filepath, episode_num, total_episodes))
            else:
                invalid_files.append((filepath, reason))
                self.log(f"⚠️ Invalid file {os.path.basename(filepath)}: {reason}")
        
        if invalid_files:
            self.log(f"⚠️ Found {len(invalid_files)} invalid files out of {len(file_paths_with_info)}")
        
        self.log(f"✅ {len(valid_files)} valid files ready for processing")
        
        return valid_files, invalid_files