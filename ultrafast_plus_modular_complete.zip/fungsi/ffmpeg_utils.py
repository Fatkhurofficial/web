"""
FFmpeg Utils Module - FFmpeg configurations dan optimizations
Optimized untuk different processing modes
"""

import platform

class FFmpegUtils:
    """FFmpeg configuration utilities"""
    
    def __init__(self):
        self.is_windows = platform.system().lower() == 'windows'
        self.cpu_count = self._get_optimal_cpu_count()
        
    def _get_optimal_cpu_count(self):
        """Get optimal CPU count untuk FFmpeg processing"""
        import multiprocessing
        total_cores = multiprocessing.cpu_count()
        
        # Conservative approach untuk memory efficiency
        return min(total_cores, 8)
    
    def get_preset_config(self, mode="ultrafast_plus"):
        """Get preset configuration untuk specific mode"""
        configs = {
            'ultrafast_plus': {
                'ffmpeg_preset': 'ultrafast',
                'crf': 27,  # Slightly better quality than pure ultrafast
                'threads': max(3, self.cpu_count // 2),
                'tune': 'fastdecode',
                'profile': 'baseline',
                'level': '3.1',
                'additional_params': [
                    '-x264opts', 'no-scenecut:no-mbtree:ref=1',
                    '-bufsize', '3M',
                    '-maxrate', '5M'
                ]
            },
            'ultrafast': {
                'ffmpeg_preset': 'ultrafast',
                'crf': 28,
                'threads': max(2, self.cpu_count // 3),
                'tune': 'fastdecode',
                'profile': 'baseline',
                'level': '3.0',
                'additional_params': [
                    '-x264opts', 'no-scenecut:no-mbtree',
                    '-bufsize', '2M'
                ]
            },
            'fast': {
                'ffmpeg_preset': 'fast',
                'crf': 25,
                'threads': max(3, self.cpu_count // 2),
                'tune': 'film',
                'profile': 'main',
                'level': '3.1',
                'additional_params': [
                    '-x264opts', 'ref=2',
                    '-bufsize', '4M'
                ]
            },
            'balanced': {
                'ffmpeg_preset': 'medium',
                'crf': 23,
                'threads': max(4, self.cpu_count // 2),
                'tune': 'film',
                'profile': 'high',
                'level': '4.0',
                'additional_params': [
                    '-x264opts', 'ref=3',
                    '-bufsize', '6M'
                ]
            }
        }
        
        return configs.get(mode, configs['ultrafast_plus'])
    
    def build_ffmpeg_params(self, mode="ultrafast_plus", custom_crf=None):
        """Build complete FFmpeg parameters untuk MoviePy"""
        config = self.get_preset_config(mode)
        
        # Use custom CRF if provided
        crf = custom_crf if custom_crf is not None else config['crf']
        
        # Base parameters
        params = [
            '-c:v', 'libx264',
            '-preset', config['ffmpeg_preset'],
            '-crf', str(crf),
            '-movflags', '+faststart',
            '-threads', str(config['threads'])
        ]
        
        # Add tune if specified
        if config.get('tune'):
            params.extend(['-tune', config['tune']])
        
        # Add profile if specified
        if config.get('profile'):
            params.extend(['-profile:v', config['profile']])
        
        # Add level if specified
        if config.get('level'):
            params.extend(['-level', config['level']])
        
        # Add additional parameters
        if config.get('additional_params'):
            params.extend(config['additional_params'])
        
        return params
    
    def get_audio_params(self, mode="ultrafast_plus"):
        """Get audio encoding parameters"""
        audio_configs = {
            'ultrafast_plus': {
                'codec': 'aac',
                'bitrate': '128k',
                'channels': 2,
                'sample_rate': '44100'
            },
            'ultrafast': {
                'codec': 'aac',
                'bitrate': '96k', 
                'channels': 2,
                'sample_rate': '44100'
            },
            'fast': {
                'codec': 'aac',
                'bitrate': '128k',
                'channels': 2,
                'sample_rate': '48000'
            },
            'balanced': {
                'codec': 'aac',
                'bitrate': '192k',
                'channels': 2,
                'sample_rate': '48000'
            }
        }
        
        return audio_configs.get(mode, audio_configs['ultrafast_plus'])
    
    def get_video_write_params(self, mode="ultrafast_plus", custom_params=None):
        """Get complete parameters untuk video writing"""
        config = self.get_preset_config(mode)
        audio_config = self.get_audio_params(mode)
        
        # Build complete parameters
        write_params = {
            'codec': 'libx264',
            'audio_codec': audio_config['codec'],
            'temp_audiofile': 'temp-audio.m4a',
            'remove_temp': True,
            'threads': config['threads'],
            'preset': config['ffmpeg_preset'],
            'ffmpeg_params': self.build_ffmpeg_params(mode, 
                                                    custom_crf=custom_params.get('crf') if custom_params else None)
        }
        
        # Add custom parameters if provided
        if custom_params:
            write_params.update(custom_params)
        
        return write_params
    
    def optimize_for_upload(self, mode="ultrafast_plus"):
        """Get optimized parameters untuk upload platforms"""
        base_params = self.build_ffmpeg_params(mode)
        
        # Add upload optimization
        upload_optimizations = [
            '-movflags', '+faststart',  # Enable fast start
            '-pix_fmt', 'yuv420p',      # Ensure compatibility
            '-g', '30',                 # GOP size
            '-keyint_min', '30',        # Minimum keyframe interval
            '-sc_threshold', '0'        # Disable scene change detection
        ]
        
        # Merge with existing params (avoid duplicates)
        final_params = []
        added_flags = set()
        
        for i in range(0, len(base_params), 2):
            if i + 1 < len(base_params):
                flag = base_params[i]
                value = base_params[i + 1]
                if flag not in added_flags:
                    final_params.extend([flag, value])
                    added_flags.add(flag)
        
        # Add upload optimizations
        for i in range(0, len(upload_optimizations), 2):
            if i + 1 < len(upload_optimizations):
                flag = upload_optimizations[i]
                value = upload_optimizations[i + 1]
                if flag not in added_flags:
                    final_params.extend([flag, value])
                    added_flags.add(flag)
        
        return final_params
    
    def get_quality_recommendations(self, total_files, total_size_gb, available_memory_gb):
        """Get quality recommendations berdasarkan system resources"""
        recommendations = {}
        
        # Base recommendations
        if total_files > 200:
            recommendations['mode'] = 'ultrafast'
            recommendations['crf'] = 28
            recommendations['reason'] = 'Many files - prioritize speed'
        elif total_files > 100:
            recommendations['mode'] = 'ultrafast_plus'
            recommendations['crf'] = 27
            recommendations['reason'] = 'Balanced approach for 100+ files'
        elif total_files > 50:
            recommendations['mode'] = 'fast'
            recommendations['crf'] = 25
            recommendations['reason'] = 'Good balance for moderate file count'
        else:
            recommendations['mode'] = 'balanced'
            recommendations['crf'] = 23
            recommendations['reason'] = 'Can afford higher quality'
        
        # Adjust based on available memory
        if available_memory_gb < 8:
            recommendations['mode'] = 'ultrafast'
            recommendations['crf'] = min(recommendations['crf'] + 2, 30)
            recommendations['memory_warning'] = 'Low memory - using fastest settings'
        elif available_memory_gb < 12:
            if recommendations['mode'] in ['balanced', 'fast']:
                recommendations['mode'] = 'ultrafast_plus'
        
        # Adjust based on total size
        if total_size_gb > 100:  # Large total size
            recommendations['crf'] = min(recommendations['crf'] + 1, 30)
            recommendations['size_note'] = 'Large input size - slightly lower quality for speed'
        
        return recommendations
    
    def estimate_output_size(self, input_size_gb, mode="ultrafast_plus", crf=None):
        """Estimate output file size berdasarkan mode dan CRF"""
        config = self.get_preset_config(mode)
        actual_crf = crf if crf is not None else config['crf']
        
        # Compression ratios berdasarkan CRF (rough estimates)
        crf_ratios = {
            18: 0.9,   # Very high quality
            20: 0.8,   # High quality
            23: 0.7,   # Good quality
            25: 0.6,   # Balanced
            27: 0.5,   # ULTRAFAST PLUS
            28: 0.45,  # ULTRAFAST
            30: 0.4    # Very compressed
        }
        
        # Get compression ratio
        ratio = crf_ratios.get(actual_crf, 0.5)
        
        # Additional mode-based adjustments
        mode_adjustments = {
            'ultrafast': 0.9,      # Less compression
            'ultrafast_plus': 0.85,
            'fast': 0.8,
            'balanced': 0.75
        }
        
        final_ratio = ratio * mode_adjustments.get(mode, 0.8)
        estimated_size = input_size_gb * final_ratio
        
        return {
            'estimated_gb': estimated_size,
            'compression_ratio': final_ratio,
            'savings_gb': input_size_gb - estimated_size,
            'savings_percent': ((input_size_gb - estimated_size) / input_size_gb) * 100
        }