"""
File Utils Module - File operations dan episode number extraction
Optimized untuk performance dan accuracy
"""

import os
import re
from pathlib import Path

class FileUtils:
    """Utility functions untuk file operations"""
    
    def __init__(self):
        self.video_extensions = ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.m4v', '.webm']
        self.episode_patterns = [
            r"(?:episode|ep|e)[\s_-]*(\d+)",  # episode 01, ep 01, e01
            r"s\d+e(\d+)",                    # s01e01
            r"(\d+)(?:\.mp4|\.avi|\.mkv|\.mov|\.wmv|\.flv|\.m4v)$",  # 01.mp4
            r"(?:^|[^\d])(\d+)(?=[^\d]*$)",   # any number at end
            r".*?(\d+).*"                     # fallback: any number
        ]
    
    def find_video_files(self, folder_path):
        """Find semua video files dalam folder"""
        if not os.path.isdir(folder_path):
            return []
            
        try:
            all_files = os.listdir(folder_path)
            video_files = [
                f for f in all_files 
                if any(f.lower().endswith(ext) for ext in self.video_extensions)
            ]
            return video_files
        except Exception as e:
            print(f"Error reading folder {folder_path}: {e}")
            return []
    
    def extract_episode_number(self, filename):
        """Extract episode number dengan multiple pattern matching"""
        filename_lower = filename.lower()
        
        # Try each pattern in order of specificity
        for pattern in self.episode_patterns:
            match = re.search(pattern, filename_lower, re.IGNORECASE)
            if match:
                try:
                    return int(match.group(1))
                except (ValueError, IndexError):
                    continue
        
        # Fallback: find longest number sequence
        numbers = re.findall(r'\d+', filename)
        if numbers:
            # Return the longest number (most likely episode number)
            return int(max(numbers, key=len))
        
        return 0  # Default if no number found
    
    def sort_files_by_episode(self, files):
        """Sort files berdasarkan episode number"""
        try:
            return sorted(files, key=self.extract_episode_number)
        except Exception as e:
            print(f"Error sorting files: {e}")
            return sorted(files)  # Fallback alphabetical sort
    
    def estimate_file_size_mb(self, filepath):
        """Estimate file size in MB dengan error handling"""
        try:
            return os.path.getsize(filepath) / (1024 * 1024)
        except (OSError, FileNotFoundError):
            return 500  # Default estimate
    
    def estimate_total_size_gb(self, file_paths):
        """Estimate total size dari semua files"""
        total_mb = sum(self.estimate_file_size_mb(fp) for fp in file_paths)
        return total_mb / 1024
    
    def validate_folder(self, folder_path):
        """Comprehensive folder validation"""
        if not folder_path:
            return False, "Path tidak boleh kosong!"
            
        if not os.path.exists(folder_path):
            return False, "Folder tidak ditemukan!"
            
        if not os.path.isdir(folder_path):
            return False, "Path bukan folder!"
            
        video_files = self.find_video_files(folder_path)
        if not video_files:
            return False, "Tidak ada file video ditemukan!"
            
        return True, video_files
    
    def get_folder_info(self, folder_path):
        """Get comprehensive folder information"""
        video_files = self.find_video_files(folder_path)
        if not video_files:
            return None
            
        # Sort files
        sorted_files = self.sort_files_by_episode(video_files)
        
        # Calculate sizes
        file_paths = [os.path.join(folder_path, f) for f in sorted_files]
        total_size_gb = self.estimate_total_size_gb(file_paths)
        
        # Sample file info untuk estimation
        sample_size = min(5, len(sorted_files))
        sample_files = sorted_files[:sample_size]
        
        return {
            'total_files': len(sorted_files),
            'sorted_files': sorted_files,
            'file_paths': file_paths,
            'total_size_gb': total_size_gb,
            'sample_files': sample_files,
            'average_size_mb': (total_size_gb * 1024) / len(sorted_files) if sorted_files else 0
        }
    
    def create_output_filename(self, folder_path, mode="ultrafast_plus"):
        """Create output filename dengan timestamp"""
        from datetime import datetime
        
        folder_name = os.path.basename(os.path.abspath(folder_path))
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        return os.path.join(folder_path, f"{folder_name}_merged_{mode}_{timestamp}.mp4")
    
    def cleanup_temp_files(self, temp_files):
        """Clean up temporary files"""
        cleaned = 0
        for temp_file in temp_files:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    cleaned += 1
            except Exception as e:
                print(f"Warning: Could not remove temp file {temp_file}: {e}")
        
        return cleaned
    
    def get_video_info_preview(self, folder_path, max_display=10):
        """Get preview information untuk user confirmation"""
        folder_info = self.get_folder_info(folder_path)
        if not folder_info:
            return None
            
        print(f"\n📁 Folder: {folder_path}")
        print(f"📊 Ditemukan {folder_info['total_files']} video files:")
        print("-" * 70)
        
        # Show sample files
        sample_count = min(max_display, folder_info['total_files'])
        for i, filename in enumerate(folder_info['sorted_files'][:sample_count], 1):
            filepath = os.path.join(folder_path, filename)
            size_mb = self.estimate_file_size_mb(filepath)
            episode_num = self.extract_episode_number(filename)
            print(f"   {i:2d}. Episode {episode_num:3d}: {filename} ({size_mb:.1f} MB)")
        
        if folder_info['total_files'] > sample_count:
            print(f"   ... dan {folder_info['total_files'] - sample_count} file lainnya")
        
        print("-" * 70)
        print(f"📊 Total size: ~{folder_info['total_size_gb']:.1f} GB")
        print(f"📊 Average size: ~{folder_info['average_size_mb']:.1f} MB per file")
        
        return folder_info
    
    def estimate_video_duration_from_size(self, size_mb, quality_factor=1.0):
        """Estimate video duration berdasarkan file size (rough estimation)"""
        # Rough calculation: 1MB ≈ 1 minute for standard quality
        # Adjust based on quality factor
        estimated_minutes = size_mb / (8 * quality_factor)  # 8MB per minute for good quality
        return max(1, estimated_minutes)  # Minimum 1 minute
    
    def get_processing_recommendations(self, folder_info, available_memory_gb):
        """Get processing recommendations berdasarkan folder info dan available memory"""
        if not folder_info:
            return None
            
        total_files = folder_info['total_files']
        total_size_gb = folder_info['total_size_gb']
        avg_size_mb = folder_info['average_size_mb']
        
        # Estimate memory requirements
        estimated_memory_need = total_size_gb * 0.3  # Conservative estimate
        
        recommendations = {
            'total_files': total_files,
            'total_size_gb': total_size_gb,
            'estimated_memory_need_gb': estimated_memory_need,
            'available_memory_gb': available_memory_gb,
            'memory_sufficient': estimated_memory_need < available_memory_gb * 0.8
        }
        
        # Mode recommendations
        if total_files > 200:
            recommendations['recommended_mode'] = 'ultrafast'
            recommendations['reason'] = 'Many files - prioritize speed'
        elif total_files > 100:
            recommendations['recommended_mode'] = 'ultrafast_plus'
            recommendations['reason'] = 'Good balance for 100+ files'
        elif total_files > 50:
            recommendations['recommended_mode'] = 'fast'
            recommendations['reason'] = 'Moderate files - balanced processing'
        else:
            recommendations['recommended_mode'] = 'balanced'
            recommendations['reason'] = 'Few files - can afford quality processing'
        
        # Memory warnings
        if not recommendations['memory_sufficient']:
            recommendations['warnings'] = [
                f"High memory usage expected: {estimated_memory_need:.1f}GB needed vs {available_memory_gb:.1f}GB available",
                "Consider using ULTRAFAST mode",
                "Close other applications to free memory"
            ]
        
        return recommendations