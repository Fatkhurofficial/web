"""
Logger Module - Enhanced logging dengan memory monitoring
"""

from datetime import datetime
import os

class Logger:
    """Enhanced logger dengan memory monitoring integration"""
    
    def __init__(self, memory_monitor=None, log_file=None):
        self.memory_monitor = memory_monitor
        self.log_file = log_file
        self.log_entries = []
        self.start_time = datetime.now()
        
    def log(self, message, show_memory=True):
        """Print log dengan timestamp dan optional memory usage"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        if show_memory and self.memory_monitor:
            memory_usage = self.memory_monitor.get_memory_usage()
            formatted_message = f"[{timestamp}] [RAM: {memory_usage:.1f}GB] {message}"
        else:
            formatted_message = f"[{timestamp}] {message}"
            
        print(formatted_message)
        
        # Store for later file writing
        self.log_entries.append({
            'timestamp': datetime.now(),
            'message': message,
            'memory_gb': self.memory_monitor.get_memory_usage() if self.memory_monitor else 0
        })
        
        # Write to file if specified
        if self.log_file:
            try:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    f.write(formatted_message + "\n")
            except:
                pass
    
    def log_memory_status(self, prefix=""):
        """Log detailed memory status"""
        if not self.memory_monitor:
            return
            
        status = self.memory_monitor.get_memory_status()
        self.log(f"{prefix}Memory Status:")
        self.log(f"{prefix}  Current: {status['current_gb']:.1f}GB ({status['usage_percent']:.1f}%)")
        self.log(f"{prefix}  Available: {status['available_gb']:.1f}GB")
        self.log(f"{prefix}  Peak: {status['peak_gb']:.1f}GB")
        self.log(f"{prefix}  Cleanups: {status['cleanup_count']}")
        
        if status['over_target']:
            self.log(f"{prefix}  ⚠️ OVER TARGET: {status['current_gb']:.1f}GB > {status['target_gb']:.1f}GB")
    
    def log_performance_summary(self, total_files, total_duration, processing_time, concat_time, write_time):
        """Log comprehensive performance summary"""
        total_time = processing_time + concat_time + write_time
        
        self.log("=" * 80, show_memory=False)
        self.log("⚡ PERFORMANCE SUMMARY:", show_memory=False)
        self.log("=" * 80, show_memory=False)
        self.log(f"Files Processed: {total_files} videos", show_memory=False)
        self.log(f"Total Duration: {total_duration/3600:.2f} hours", show_memory=False)
        self.log(f"Processing: {processing_time:.1f}s | Concat: {concat_time:.1f}s | Write: {write_time:.1f}s", show_memory=False)
        self.log(f"Total Time: {total_time:.1f}s | Speed: {total_duration/total_time:.1f}x realtime", show_memory=False)
        self.log(f"Throughput: {total_files/total_time:.2f} videos/second", show_memory=False)
        
        if self.memory_monitor:
            status = self.memory_monitor.get_memory_status()
            self.log(f"Memory Peak: {status['peak_gb']:.1f}GB | Final: {status['current_gb']:.1f}GB", show_memory=False)
            self.log(f"Memory Cleanups: {status['cleanup_count']}", show_memory=False)
        
        self.log("=" * 80, show_memory=False)
    
    def log_copyright_protection_summary(self, video_log, config):
        """Log copyright protection effectiveness"""
        if not video_log:
            return
            
        # Calculate effect statistics
        total_videos = len(video_log)
        effects_count = {
            'speed_changes': sum(1 for v in video_log if abs(v['params']['speed'] - 1.0) > 0.002),
            'brightness_changes': sum(1 for v in video_log if abs(v['params']['brightness'] - 1.0) > 0.02),
            'margin_applied': sum(1 for v in video_log if v['params'].get('margin', 0) > 3),
            'audio_changes': sum(1 for v in video_log if abs(v['params']['audio_volume'] - 1.0) > 0.015),
            'gamma_applied': sum(1 for v in video_log if v['params'].get('gamma')),
            'crop_applied': sum(1 for v in video_log if v['params'].get('crop_percent', 0) > 0.5)
        }
        
        self.log("🛡️ COPYRIGHT PROTECTION SUMMARY:", show_memory=False)
        self.log(f"Protection Level: {config.get('copyright_protection_level', 'standard').upper()}", show_memory=False)
        self.log(f"Speed Variations: {effects_count['speed_changes']}/{total_videos} videos ({effects_count['speed_changes']/total_videos*100:.1f}%)", show_memory=False)
        self.log(f"Brightness Changes: {effects_count['brightness_changes']}/{total_videos} videos ({effects_count['brightness_changes']/total_videos*100:.1f}%)", show_memory=False)
        self.log(f"Margin Applied: {effects_count['margin_applied']}/{total_videos} videos ({effects_count['margin_applied']/total_videos*100:.1f}%)", show_memory=False)
        self.log(f"Audio Modifications: {effects_count['audio_changes']}/{total_videos} videos ({effects_count['audio_changes']/total_videos*100:.1f}%)", show_memory=False)
        self.log(f"Gamma Correction: {effects_count['gamma_applied']}/{total_videos} videos ({effects_count['gamma_applied']/total_videos*100:.1f}%)", show_memory=False)
        self.log(f"Cropping Applied: {effects_count['crop_applied']}/{total_videos} videos ({effects_count['crop_applied']/total_videos*100:.1f}%)", show_memory=False)
        
        # Calculate overall effectiveness
        total_effects = sum(effects_count.values())
        max_possible_effects = total_videos * 6  # 6 possible effects per video
        effectiveness = (total_effects / max_possible_effects) * 100
        
        self.log(f"Overall Effectiveness: {effectiveness:.1f}% ({total_effects}/{max_possible_effects} effects applied)", show_memory=False)
    
    def save_detailed_log(self, folder_path, output_file, video_log, config):
        """Save comprehensive log file"""
        folder_name = os.path.basename(os.path.abspath(folder_path))
        log_file = os.path.join(folder_path, f"{folder_name}_ultrafast_plus_detailed_log.txt")

        try:
            with open(log_file, 'w', encoding='utf-8') as f:
                # Header
                f.write("=" * 100 + "\n")
                f.write(f"ULTRAFAST PLUS VIDEO MERGER - DETAILED LOG\n")
                f.write("=" * 100 + "\n")
                f.write(f"Folder: {folder_name}\n")
                f.write(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Processing Mode: {config.get('mode', 'unknown').upper()}\n")
                f.write(f"Copyright Protection: {config.get('copyright_protection_level', 'standard').upper()}\n")
                f.write(f"Total Videos: {len(video_log)}\n")
                f.write(f"Output File: {os.path.basename(output_file)}\n")
                
                if self.memory_monitor:
                    status = self.memory_monitor.get_memory_status()
                    f.write(f"Peak Memory Usage: {status['peak_gb']:.1f}GB\n")
                    f.write(f"Final Memory Usage: {status['current_gb']:.1f}GB\n")
                    f.write(f"Memory Cleanups: {status['cleanup_count']}\n")
                
                f.write("=" * 100 + "\n\n")

                # Video processing details
                f.write("VIDEO PROCESSING DETAILS:\n")
                f.write("-" * 100 + "\n")
                
                total_duration = 0
                total_input_size = 0
                
                for i, video_info in enumerate(video_log, 1):
                    f.write(f"{i:3d}. Episode {video_info['episode']:3d}: {video_info['filename']}\n")
                    f.write(f"     Duration: {video_info['processed_duration']:.1f}s")
                    f.write(f" | Size: {video_info.get('file_size_mb', 0):.1f}MB")
                    f.write(f" | Memory: {video_info.get('memory_usage', 0):.1f}GB\n")
                    
                    # Parameters detail
                    params = video_info['params']
                    f.write(f"     Speed: {params['speed']:.4f}x")
                    f.write(f" | Brightness: {params['brightness']:.3f}")
                    f.write(f" | Margin: {params.get('margin', 0)}px")
                    f.write(f" | Audio: {params['audio_volume']:.3f}\n")
                    
                    if params.get('gamma'):
                        f.write(f"     Gamma: {params['gamma']:.3f}")
                    if params.get('crop_percent'):
                        f.write(f" | Crop: {params['crop_percent']:.2f}%")
                    if params.get('fade_duration'):
                        f.write(f" | Fade: {params['fade_duration']:.3f}s")
                    f.write("\n")
                    
                    total_duration += video_info['processed_duration']
                    total_input_size += video_info.get('file_size_mb', 0)
                    
                    if i % 10 == 0:
                        f.write("-" * 50 + "\n")

                # Summary
                f.write(f"\nPROCESSING SUMMARY:\n")
                f.write(f"Total Duration: {total_duration/60:.1f} minutes ({total_duration/3600:.2f} hours)\n")
                f.write(f"Total Input Size: {total_input_size/1024:.1f}GB\n")
                f.write(f"Processing Time: {(datetime.now() - self.start_time).total_seconds():.1f} seconds\n")
                f.write("=" * 100 + "\n")

            self.log(f"📄 Detailed log saved: {log_file}")
            return log_file

        except Exception as e:
            self.log(f"⚠️ Warning: Failed to save detailed log: {e}")
            return None