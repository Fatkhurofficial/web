#pragma once

#include <string>
#include <atomic>
#include <functional>
#include <windows.h>

class ProgressTracker
{
public:
    using NotificationCallback = std::function<void(const std::string& title, const std::string& message)>;

    ProgressTracker();
    ~ProgressTracker();

    // Progress tracking
    void SetProgress(float progress, const std::string& task = "");
    float GetProgress() const { return m_progress; }
    std::string GetCurrentTask() const { return m_currentTask; }

    // System tray notifications
    void ShowNotification(const std::string& title, const std::string& message);
    void SetNotificationCallback(NotificationCallback callback);

    // Background processing state
    void SetProcessingState(bool isProcessing);
    bool IsProcessing() const { return m_isProcessing; }

    // Time estimation
    void StartTimer();
    void StopTimer();
    double GetElapsedTime() const;
    double EstimateRemainingTime() const;

private:
    void InitializeSystemTray();
    void CleanupSystemTray();
    void UpdateTrayIcon();
    
    static LRESULT CALLBACK TrayWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

    // Progress data
    std::atomic<float> m_progress;
    std::string m_currentTask;
    std::atomic<bool> m_isProcessing;

    // Timing
    LARGE_INTEGER m_startTime;
    LARGE_INTEGER m_frequency;
    bool m_timerStarted;

    // System tray
    HWND m_trayWindow;
    NOTIFYICONDATA m_trayIconData;
    bool m_trayInitialized;
    NotificationCallback m_notificationCallback;

    // Constants
    static const UINT WM_TRAYICON = WM_USER + 1;
    static const UINT TRAY_ID = 1;
};