#include "VideoMerger.h"
#include "imgui.h"
#include <algorithm>
#include <filesystem>
#include <sstream>

VideoMerger::VideoMerger()
    : m_videoProcessor(std::make_unique<VideoProcessor>())
    , m_fileManager(std::make_unique<FileManager>())
    , m_progressTracker(std::make_unique<ProgressTracker>())
    , m_selectedPreviewIndex(-1)
    , m_isProcessing(false)
    , m_showPreview(false)
    , m_showSettings(false)
    , m_showProgress(false)
    , m_autoDetectEpisodes(true)
    , m_enableAntiCopyright(false)
    , m_outputPath("./output/")
    , m_filenameTemplate("Merged_Video_{timestamp}")
    , m_videoQuality(23) // CRF value for H.264
    , m_audioQuality(128) // AAC bitrate in kbps
    , m_outputFormat("mp4")
    , m_currentProgress(0.0f)
    , m_currentTask("Ready")
    , m_statusMessage("Ready to merge videos")
{
    // Create output directory if it doesn't exist
    std::filesystem::create_directories(m_outputPath);
}

VideoMerger::~VideoMerger()
{
    if (m_isProcessing && m_processingThread.joinable())
    {
        StopMerging();
        m_processingThread.join();
    }
}

void VideoMerger::Render()
{
    RenderMenuBar();
    RenderMainWindow();
    
    if (m_showPreview)
        RenderPreviewWindow();
    
    if (m_showSettings)
        RenderSettingsPanel();
    
    if (m_showProgress)
        RenderProgressWindow();
}

void VideoMerger::RenderMenuBar()
{
    if (ImGui::BeginMenuBar())
    {
        if (ImGui::BeginMenu("File"))
        {
            if (ImGui::MenuItem("Add Videos...", "Ctrl+O"))
            {
                auto files = m_fileManager->OpenFileDialog(true);
                for (const auto& file : files)
                {
                    AddVideoFile(file);
                }
            }
            
            if (ImGui::MenuItem("Clear All", "Ctrl+N"))
            {
                std::lock_guard<std::mutex> lock(m_filesMutex);
                m_videoFiles.clear();
                m_selectedFiles.clear();
                m_selectedPreviewIndex = -1;
            }
            
            ImGui::Separator();
            
            if (ImGui::MenuItem("Exit", "Alt+F4"))
            {
                // Handle exit
            }
            
            ImGui::EndMenu();
        }
        
        if (ImGui::BeginMenu("View"))
        {
            ImGui::MenuItem("Video Preview", nullptr, &m_showPreview);
            ImGui::MenuItem("Settings", nullptr, &m_showSettings);
            ImGui::MenuItem("Progress", nullptr, &m_showProgress);
            ImGui::EndMenu();
        }
        
        if (ImGui::BeginMenu("Help"))
        {
            if (ImGui::MenuItem("About"))
            {
                // Show about dialog
            }
            ImGui::EndMenu();
        }
        
        ImGui::EndMenuBar();
    }
}

void VideoMerger::RenderMainWindow()
{
    ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(800, 600), ImGuiCond_FirstUseEver);
    
    ImGui::Begin("VideoMerger - Main Window", nullptr, ImGuiWindowFlags_MenuBar);
    
    RenderMenuBar();
    
    // Drag & Drop area
    ImGui::Text("Drag & Drop Video Files Here");
    ImGui::Separator();
    
    // Video list
    RenderVideoList();
    
    ImGui::Separator();
    
    // Control buttons
    ImGui::BeginGroup();
    {
        if (ImGui::Button("Add Videos", ImVec2(100, 30)))
        {
            auto files = m_fileManager->OpenFileDialog(true);
            for (const auto& file : files)
            {
                AddVideoFile(file);
            }
        }
        
        ImGui::SameLine();
        
        if (ImGui::Button("Remove Selected", ImVec2(120, 30)))
        {
            // Remove selected videos
            for (int i = m_selectedFiles.size() - 1; i >= 0; i--)
            {
                if (m_selectedFiles[i])
                {
                    RemoveVideoFile(i);
                }
            }
        }
        
        ImGui::SameLine();
        
        if (ImGui::Button("Clear All", ImVec2(100, 30)))
        {
            std::lock_guard<std::mutex> lock(m_filesMutex);
            m_videoFiles.clear();
            m_selectedFiles.clear();
            m_selectedPreviewIndex = -1;
        }
    }
    ImGui::EndGroup();
    
    ImGui::Separator();
    
    // Feature toggles
    ImGui::Checkbox("Auto-detect Episodes", &m_autoDetectEpisodes);
    ImGui::SameLine();
    ImGui::Checkbox("Enable Anti-Copyright Protection", &m_enableAntiCopyright);
    
    // Output settings
    ImGui::Text("Output Path:");
    ImGui::SameLine();
    char outputBuffer[512];
    strcpy_s(outputBuffer, m_outputPath.c_str());
    if (ImGui::InputText("##output", outputBuffer, sizeof(outputBuffer)))
    {
        m_outputPath = outputBuffer;
    }
    
    ImGui::SameLine();
    if (ImGui::Button("Browse"))
    {
        std::string folder = m_fileManager->SelectFolderDialog();
        if (!folder.empty())
        {
            m_outputPath = folder;
        }
    }
    
    ImGui::Separator();
    
    // Start/Stop buttons
    ImGui::BeginGroup();
    {
        bool canStart = !m_videoFiles.empty() && !m_isProcessing;
        
        if (!canStart) ImGui::BeginDisabled();
        if (ImGui::Button("Start Merging", ImVec2(120, 40)))
        {
            StartMerging();
        }
        if (!canStart) ImGui::EndDisabled();
        
        ImGui::SameLine();
        
        bool canStop = m_isProcessing;
        if (!canStop) ImGui::BeginDisabled();
        if (ImGui::Button("Stop", ImVec2(80, 40)))
        {
            StopMerging();
        }
        if (!canStop) ImGui::EndDisabled();
    }
    ImGui::EndGroup();
    
    // Status bar
    ImGui::Separator();
    ImGui::Text("Status: %s", m_statusMessage.c_str());
    if (m_isProcessing)
    {
        ImGui::SameLine();
        ImGui::ProgressBar(m_currentProgress, ImVec2(-1, 0), m_currentTask.c_str());
    }
    
    ImGui::End();
}

void VideoMerger::RenderVideoList()
{
    ImGui::BeginChild("VideoList", ImVec2(0, 300), true);
    
    std::lock_guard<std::mutex> lock(m_filesMutex);
    
    if (m_videoFiles.empty())
    {
        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "No videos added yet. Drag & drop or use 'Add Videos' button.");
    }
    else
    {
        // Ensure selectedFiles vector has correct size
        if (m_selectedFiles.size() != m_videoFiles.size())
        {
            m_selectedFiles.resize(m_videoFiles.size(), false);
        }
        
        for (size_t i = 0; i < m_videoFiles.size(); i++)
        {
            ImGui::PushID(static_cast<int>(i));
            
            bool selected = m_selectedFiles[i];
            if (ImGui::Checkbox("##select", &selected))
            {
                m_selectedFiles[i] = selected;
            }
            
            ImGui::SameLine();
            
            // Get filename only
            std::filesystem::path filepath(m_videoFiles[i]);
            std::string filename = filepath.filename().string();
            
            if (ImGui::Selectable(filename.c_str(), i == m_selectedPreviewIndex))
            {
                m_selectedPreviewIndex = static_cast<int>(i);
            }
            
            // Show file info on hover
            if (ImGui::IsItemHovered())
            {
                ImGui::BeginTooltip();
                ImGui::Text("Full Path: %s", m_videoFiles[i].c_str());
                // Add more video info here (duration, resolution, etc.)
                ImGui::EndTooltip();
            }
            
            ImGui::PopID();
        }
    }
    
    ImGui::EndChild();
}

void VideoMerger::RenderPreviewWindow()
{
    ImGui::Begin("Video Preview", &m_showPreview);
    
    if (m_selectedPreviewIndex >= 0 && m_selectedPreviewIndex < m_videoFiles.size())
    {
        std::string currentFile = m_videoFiles[m_selectedPreviewIndex];
        ImGui::Text("Previewing: %s", std::filesystem::path(currentFile).filename().string().c_str());
        
        // Video preview would be implemented here
        // For now, show placeholder
        ImGui::BeginChild("VideoPreview", ImVec2(640, 360), true);
        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Video Preview");
        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "(Preview functionality will be implemented)");
        ImGui::EndChild();
        
        // Video controls
        ImGui::Button("Play/Pause");
        ImGui::SameLine();
        ImGui::Button("Stop");
        ImGui::SameLine();
        ImGui::SliderFloat("##progress", &m_currentProgress, 0.0f, 1.0f, "%.1f");
    }
    else
    {
        ImGui::Text("Select a video from the main window to preview");
    }
    
    ImGui::End();
}

void VideoMerger::RenderSettingsPanel()
{
    ImGui::Begin("Settings", &m_showSettings);
    
    ImGui::SeparatorText("Output Settings");
    
    // Filename template
    ImGui::Text("Filename Template:");
    char templateBuffer[256];
    strcpy_s(templateBuffer, m_filenameTemplate.c_str());
    if (ImGui::InputText("##template", templateBuffer, sizeof(templateBuffer)))
    {
        m_filenameTemplate = templateBuffer;
    }
    ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Variables: {timestamp}, {date}, {count}");
    
    // Output format
    const char* formats[] = { "mp4", "avi", "mkv", "mov" };
    int currentFormat = 0;
    for (int i = 0; i < 4; i++)
    {
        if (m_outputFormat == formats[i])
        {
            currentFormat = i;
            break;
        }
    }
    
    if (ImGui::Combo("Output Format", &currentFormat, formats, 4))
    {
        m_outputFormat = formats[currentFormat];
    }
    
    ImGui::SeparatorText("Quality Settings");
    
    // Video quality (CRF)
    ImGui::SliderInt("Video Quality (CRF)", &m_videoQuality, 18, 28);
    ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Lower = Higher Quality, Higher = Smaller File");
    
    // Audio quality
    ImGui::SliderInt("Audio Bitrate (kbps)", &m_audioQuality, 64, 320);
    
    ImGui::SeparatorText("Processing Options");
    
    ImGui::Checkbox("Auto-detect and Sort Episodes", &m_autoDetectEpisodes);
    ImGui::Checkbox("Enable Anti-Copyright Protection", &m_enableAntiCopyright);
    
    if (ImGui::Button("Reset to Defaults"))
    {
        m_videoQuality = 23;
        m_audioQuality = 128;
        m_outputFormat = "mp4";
        m_filenameTemplate = "Merged_Video_{timestamp}";
        m_autoDetectEpisodes = true;
        m_enableAntiCopyright = false;
    }
    
    ImGui::End();
}

void VideoMerger::RenderProgressWindow()
{
    ImGui::Begin("Progress", &m_showProgress);
    
    ImGui::Text("Current Task: %s", m_currentTask.c_str());
    ImGui::ProgressBar(m_currentProgress, ImVec2(-1, 0));
    ImGui::Text("Status: %s", m_statusMessage.c_str());
    
    // Show detailed progress info
    if (m_isProcessing)
    {
        ImGui::Separator();
        ImGui::Text("Processing in background...");
        
        // Show system tray notification option
        static bool enableNotifications = true;
        ImGui::Checkbox("Enable System Tray Notifications", &enableNotifications);
    }
    
    ImGui::End();
}

void VideoMerger::AddVideoFile(const std::string& filepath)
{
    std::lock_guard<std::mutex> lock(m_filesMutex);
    
    // Check if file already exists
    auto it = std::find(m_videoFiles.begin(), m_videoFiles.end(), filepath);
    if (it == m_videoFiles.end())
    {
        m_videoFiles.push_back(filepath);
        m_selectedFiles.push_back(false);
        
        // Auto-sort if enabled
        if (m_autoDetectEpisodes)
        {
            UpdateVideoList();
        }
    }
}

void VideoMerger::RemoveVideoFile(int index)
{
    std::lock_guard<std::mutex> lock(m_filesMutex);
    
    if (index >= 0 && index < m_videoFiles.size())
    {
        m_videoFiles.erase(m_videoFiles.begin() + index);
        m_selectedFiles.erase(m_selectedFiles.begin() + index);
        
        if (m_selectedPreviewIndex == index)
        {
            m_selectedPreviewIndex = -1;
        }
        else if (m_selectedPreviewIndex > index)
        {
            m_selectedPreviewIndex--;
        }
    }
}

void VideoMerger::StartMerging()
{
    if (m_isProcessing || m_videoFiles.empty())
        return;
    
    m_isProcessing = true;
    m_currentProgress = 0.0f;
    m_currentTask = "Initializing...";
    m_statusMessage = "Starting video merge process";
    m_showProgress = true;
    
    // Start background processing thread
    m_processingThread = std::thread(&VideoMerger::ProcessVideosInBackground, this);
}

void VideoMerger::StopMerging()
{
    m_isProcessing = false;
    m_currentTask = "Stopping...";
    m_statusMessage = "Stopping merge process";
    
    if (m_processingThread.joinable())
    {
        m_processingThread.join();
    }
    
    m_currentTask = "Stopped";
    m_statusMessage = "Merge process stopped";
}

void VideoMerger::UpdateVideoList()
{
    // Sort videos if auto-detect is enabled
    if (m_autoDetectEpisodes)
    {
        std::sort(m_videoFiles.begin(), m_videoFiles.end());
    }
}

void VideoMerger::ProcessVideosInBackground()
{
    try
    {
        // Generate output filename
        auto now = std::chrono::system_clock::now();
        auto time_t = std::chrono::system_clock::to_time_t(now);
        
        std::string timestamp = std::to_string(time_t);
        std::string outputFilename = m_filenameTemplate;
        
        // Replace template variables
        size_t pos = outputFilename.find("{timestamp}");
        if (pos != std::string::npos)
        {
            outputFilename.replace(pos, 11, timestamp);
        }
        
        std::string outputPath = m_outputPath + "/" + outputFilename + "." + m_outputFormat;
        
        // Start video processing
        m_currentTask = "Processing videos...";
        m_statusMessage = "Merging " + std::to_string(m_videoFiles.size()) + " videos";
        
        bool success = m_videoProcessor->MergeVideos(m_videoFiles, outputPath, 
            [this](float progress, const std::string& task) {
                m_currentProgress = progress;
                m_currentTask = task;
            });
        
        if (success)
        {
            m_currentProgress = 1.0f;
            m_currentTask = "Complete";
            m_statusMessage = "Videos merged successfully: " + outputPath;
        }
        else
        {
            m_currentTask = "Failed";
            m_statusMessage = "Failed to merge videos";
        }
    }
    catch (const std::exception& e)
    {
        m_currentTask = "Error";
        m_statusMessage = "Error: " + std::string(e.what());
    }
    
    m_isProcessing = false;
}