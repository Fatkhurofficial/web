#pragma once

#include <string>
#include <vector>
#include <functional>

extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/avutil.h>
#include <libavutil/opt.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

class VideoProcessor
{
public:
    using ProgressCallback = std::function<void(float progress, const std::string& task)>;

    VideoProcessor();
    ~VideoProcessor();

    bool Initialize();
    void Cleanup();

    // Core video processing functions
    bool MergeVideos(const std::vector<std::string>& inputFiles, 
                     const std::string& outputFile, 
                     ProgressCallback progressCallback = nullptr);

    bool GetVideoInfo(const std::string& inputFile, 
                      int& width, int& height, 
                      double& duration, double& fps);

    // Anti-copyright protection
    bool ApplyAntiCopyrightFilter(const std::string& inputFile, 
                                  const std::string& outputFile);

    // Episode detection and sorting
    std::vector<std::string> SortVideosByEpisode(const std::vector<std::string>& files);

    // Quality settings
    void SetVideoQuality(int crf) { m_videoCRF = crf; }
    void SetAudioBitrate(int bitrate) { m_audioBitrate = bitrate; }
    void SetOutputFormat(const std::string& format) { m_outputFormat = format; }

private:
    bool InitializeFFmpeg();
    void CleanupFFmpeg();

    // FFmpeg context management
    AVFormatContext* OpenInputFile(const std::string& filename);
    AVFormatContext* CreateOutputContext(const std::string& filename);
    void CloseContext(AVFormatContext* context);

    // Video processing helpers
    bool CopyStream(AVFormatContext* inputCtx, AVFormatContext* outputCtx, 
                    int inputStreamIndex, int outputStreamIndex);
    
    bool ProcessVideoStream(AVFormatContext* inputCtx, AVFormatContext* outputCtx,
                           int inputStreamIndex, int outputStreamIndex,
                           ProgressCallback progressCallback);

    bool ProcessAudioStream(AVFormatContext* inputCtx, AVFormatContext* outputCtx,
                           int inputStreamIndex, int outputStreamIndex);

    // Episode detection
    int ExtractEpisodeNumber(const std::string& filename);
    double CalculateVideoSimilarity(const std::string& file1, const std::string& file2);

    // Settings
    int m_videoCRF;
    int m_audioBitrate;
    std::string m_outputFormat;
    
    // FFmpeg initialization state
    bool m_isInitialized;
    
    // Progress tracking
    ProgressCallback m_currentProgressCallback;
    size_t m_totalFiles;
    size_t m_currentFileIndex;
};