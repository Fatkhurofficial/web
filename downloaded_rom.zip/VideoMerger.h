#pragma once

#include <vector>
#include <string>
#include <memory>
#include <thread>
#include <atomic>
#include <mutex>
#include "VideoProcessor.h"
#include "FileManager.h"
#include "ProgressTracker.h"

class VideoMerger
{
public:
    VideoMerger();
    ~VideoMerger();

    void Render();
    void AddVideoFile(const std::string& filepath);
    void RemoveVideoFile(int index);
    void StartMerging();
    void StopMerging();
    
private:
    void RenderMainWindow();
    void RenderVideoList();
    void RenderPreviewWindow();
    void RenderSettingsPanel();
    void RenderProgressWindow();
    void RenderMenuBar();
    
    void UpdateVideoList();
    void ProcessVideosInBackground();
    
    // Core components
    std::unique_ptr<VideoProcessor> m_videoProcessor;
    std::unique_ptr<FileManager> m_fileManager;
    std::unique_ptr<ProgressTracker> m_progressTracker;
    
    // Video file management
    std::vector<std::string> m_videoFiles;
    std::vector<bool> m_selectedFiles;
    int m_selectedPreviewIndex;
    
    // Processing state
    std::atomic<bool> m_isProcessing;
    std::thread m_processingThread;
    std::mutex m_filesMutex;
    
    // GUI state
    bool m_showPreview;
    bool m_showSettings;
    bool m_showProgress;
    bool m_autoDetectEpisodes;
    bool m_enableAntiCopyright;
    
    // Settings
    std::string m_outputPath;
    std::string m_filenameTemplate;
    int m_videoQuality;
    int m_audioQuality;
    std::string m_outputFormat;
    
    // Progress tracking
    float m_currentProgress;
    std::string m_currentTask;
    std::string m_statusMessage;
};