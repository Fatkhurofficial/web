#!/usr/bin/env python3
"""
Auto-run ULTRAFAST PLUS dengan mode ultrafast untuk folder Kapsul Waktu Penyesalan
"""

import os
import sys
import platform
import time
import multiprocessing
from datetime import datetime

# Add fungsi path
sys.path.append(os.path.join(os.path.dirname(__file__), 'fungsi'))

def main():
    """Auto-run dengan mode ultrafast"""
    print("=" * 90)
    print("🚀 AUTO-RUNNING ULTRAFAST PLUS MODULAR VIDEO MERGER")
    print("=" * 90)
    print(f"💻 System: {platform.system()} {platform.release()}")
    print("🎯 Mode: ULTRAFAST (Auto-selected)")
    print("📁 Folder: Kapsul Waktu Penyesalan")
    print("-" * 90)

    # Windows multiprocessing support
    if platform.system().lower() == 'windows':
        multiprocessing.freeze_support()

    # Check dependencies
    print("\n🔍 Checking dependencies...")
    try:
        import moviepy
        from PIL import Image
        import numpy
        import psutil
        print("✅ All dependencies OK!")
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        return

    # Import after dependency check
    try:
        from fungsi import MemoryMonitor, VideoProcessor, FileUtils, FFmpegUtils, Logger
        from ultrafast_plus_modular import UltraFastPlusModular
    except ImportError as e:
        print(f"❌ Error importing modules: {e}")
        return

    # Set parameters
    speed_mode = "ultrafast"  # Mode yang diminta user
    folder_input = "/app/Kapsul Waktu Penyesalan"
    
    # Validate folder
    file_utils = FileUtils()
    is_valid, result = file_utils.validate_folder(folder_input)
    if not is_valid:
        print(f"❌ {result}")
        return

    # Show folder info
    folder_info = file_utils.get_video_info_preview(folder_input)
    if not folder_info:
        print("❌ Could not analyze folder!")
        return

    # Memory check
    total_ram = psutil.virtual_memory().total / (1024**3)
    available_ram = psutil.virtual_memory().available / (1024**3)
    
    print(f"\n💾 System RAM: {total_ram:.1f}GB | Available: {available_ram:.1f}GB")
    
    # Get processing recommendations
    recommendations = file_utils.get_processing_recommendations(folder_info, available_ram)
    
    if recommendations:
        print(f"\n🎯 PROCESSING ANALYSIS:")
        print(f"Files: {recommendations['total_files']} videos")
        print(f"Size: {recommendations['total_size_gb']:.1f}GB")
        print(f"Memory: {recommendations['estimated_memory_need_gb']:.1f}GB needed vs {available_ram:.1f}GB available")
        print(f"Mode: ULTRAFAST (user selected)")
        
        if recommendations.get('warnings'):
            print("⚠️ WARNINGS:")
            for warning in recommendations['warnings']:
                print(f"   • {warning}")

    # Final configuration
    print(f"\n🎯 FINAL CONFIGURATION:")
    print(f"Folder: {folder_input}")
    print(f"Mode: ULTRAFAST")
    print(f"Files: {folder_info['total_files']} videos")
    print(f"Architecture: MODULAR")
    print(f"🛡️ Copyright Protection: BASIC (60-70%)")
    print(f"📊 Expected effects per video: 3-4 modifications")

    # Time estimation
    est_time = folder_info['total_files'] * 0.08  # ultrafast estimation
    print(f"⏱️ Estimated time: ~{est_time:.1f} seconds ({est_time/60:.1f} minutes)")

    print(f"\n🚀 STARTING ULTRAFAST PROCESSING...")
    print("=" * 90)

    try:
        merger = UltraFastPlusModular(speed_mode, max_memory_gb=16)
        merger.merge_videos_modular(folder_input)

        print("=" * 90)
        print("🎉 ULTRAFAST PROCESSING COMPLETED!")
        print("💡 ULTRAFAST MODE BENEFITS:")
        print("  • Maximum processing speed")
        print("  • Conservative memory usage")
        print("  • Basic copyright protection")
        print("  • Optimized for quick results")
        print("  • Check detailed log for comprehensive analysis")
        print("=" * 90)

    except Exception as e:
        import traceback
        print(f"❌ Error during processing: {e}")
        print("Full traceback:")
        traceback.print_exc()
        print("💡 TROUBLESHOOTING:")
        print("  • Check if all modules are properly installed")
        print("  • Verify sufficient RAM availability")
        print("  • Check log files for detailed error analysis")

if __name__ == "__main__":
    main()