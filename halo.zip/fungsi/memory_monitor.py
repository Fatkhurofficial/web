"""
Memory Monitor Module - Real-time memory monitoring dan adaptive batch sizing
Optimized untuk 150+ video files dengan durasi panjang
"""

import psutil
import gc
import time

class MemoryMonitor:
    """Real-time memory monitoring untuk video processing"""
    
    def __init__(self, target_usage_percent=75):
        self.target_usage_percent = target_usage_percent
        self.total_memory = psutil.virtual_memory().total / (1024**3)  # GB
        self.target_memory = self.total_memory * (target_usage_percent / 100)
        self.monitoring = False
        self.current_usage = 0
        self.peak_usage = 0
        self.cleanup_count = 0
        
    def get_memory_usage(self):
        """Get current memory usage in GB"""
        current = psutil.virtual_memory().used / (1024**3)
        self.current_usage = current
        if current > self.peak_usage:
            self.peak_usage = current
        return current
    
    def get_available_memory(self):
        """Get available memory in GB"""
        return psutil.virtual_memory().available / (1024**3)
    
    def get_memory_percent(self):
        """Get memory usage percentage"""
        return psutil.virtual_memory().percent
    
    def should_reduce_batch(self):
        """Check if we should reduce batch size"""
        current = self.get_memory_usage()
        return current > self.target_memory
    
    def get_optimal_batch_size_for_long_videos(self, base_batch_size, avg_duration_minutes):
        """Calculate optimal batch size berdasarkan durasi video dan available memory"""
        available_gb = self.get_available_memory()
        
        # Estimate memory per video berdasarkan durasi
        if avg_duration_minutes > 30:  # Video sangat panjang
            memory_per_video_gb = 1.0  # 1GB per video
            max_files = int(available_gb * 0.6 / memory_per_video_gb)
        elif avg_duration_minutes > 20:  # Video panjang  
            memory_per_video_gb = 0.8  # 800MB per video
            max_files = int(available_gb * 0.7 / memory_per_video_gb)
        elif avg_duration_minutes > 10:  # Video sedang
            memory_per_video_gb = 0.5  # 500MB per video
            max_files = int(available_gb * 0.75 / memory_per_video_gb)
        else:  # Video pendek
            memory_per_video_gb = 0.3  # 300MB per video
            max_files = int(available_gb * 0.8 / memory_per_video_gb)
        
        # Safety limits
        optimal_size = min(max_files, base_batch_size, 30)
        return max(2, optimal_size)  # Minimum 2 files per batch
    
    def aggressive_cleanup_for_long_videos(self):
        """Enhanced cleanup untuk video dengan durasi panjang"""
        self.cleanup_count += 1
        
        # Standard garbage collection
        gc.collect()
        
        # Clear moviepy cache
        try:
            import moviepy.config as mp_config
            if hasattr(mp_config, 'clear_temp'):
                mp_config.clear_temp()
        except:
            pass
            
        # Clear matplotlib cache jika ada
        try:
            import matplotlib
            matplotlib.pyplot.close('all')
            matplotlib.pyplot.clf()
        except:
            pass
            
        # Clear numpy cache
        try:
            import numpy as np
            if hasattr(np, 'clear_cache'):
                np.clear_cache()
        except:
            pass
            
        # Force memory release ke OS
        if hasattr(gc, 'set_threshold'):
            gc.set_threshold(0)  # Disable auto GC
            gc.collect()
            gc.set_threshold(700, 10, 10)  # Reset to default
            
        # Brief pause untuk system memory management
        time.sleep(0.1)
    
    def get_memory_status(self):
        """Get comprehensive memory status"""
        return {
            'current_gb': self.get_memory_usage(),
            'available_gb': self.get_available_memory(),
            'total_gb': self.total_memory,
            'usage_percent': self.get_memory_percent(),
            'target_gb': self.target_memory,
            'peak_gb': self.peak_usage,
            'cleanup_count': self.cleanup_count,
            'over_target': self.get_memory_usage() > self.target_memory
        }
    
    def log_memory_status(self, logger, prefix=""):
        """Log current memory status"""
        status = self.get_memory_status()
        logger.log(f"{prefix}Memory: {status['current_gb']:.1f}GB/{status['total_gb']:.1f}GB ({status['usage_percent']:.1f}%)")
        
        if status['over_target']:
            logger.log(f"{prefix}⚠️ Over target! Current: {status['current_gb']:.1f}GB > Target: {status['target_gb']:.1f}GB")
    
    def estimate_processing_capacity(self, avg_file_size_mb, avg_duration_minutes):
        """Estimate berapa video yang bisa diproses simultaneously"""
        available_gb = self.get_available_memory()
        
        # Processing overhead calculation
        base_memory_mb = avg_file_size_mb * 2  # Base video loading
        duration_overhead_mb = avg_duration_minutes * 50  # Duration processing overhead
        effects_overhead_mb = 200  # Effects processing overhead
        
        total_memory_per_video_mb = base_memory_mb + duration_overhead_mb + effects_overhead_mb
        total_memory_per_video_gb = total_memory_per_video_mb / 1024
        
        max_concurrent = int(available_gb * 0.7 / total_memory_per_video_gb)
        
        return {
            'max_concurrent_videos': max(1, max_concurrent),
            'memory_per_video_gb': total_memory_per_video_gb,
            'recommended_batch_size': min(max_concurrent, 20)
        }