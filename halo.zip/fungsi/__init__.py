"""
ULTRAFAST PLUS Video Merger - Modular Functions Package
Organized functions untuk maximum performance dan maintainability
"""

from .memory_monitor import MemoryMonitor
from .video_processor import VideoProcessor
from .file_utils import FileUtils
from .ffmpeg_utils import FFmpegUtils
from .logger import Logger

__version__ = "2.0.0"
__author__ = "ULTRAFAST PLUS Team"

# Export main classes
__all__ = [
    'MemoryMonitor',
    'VideoProcessor', 
    'FileUtils',
    'FFmpegUtils',
    'Logger'
]